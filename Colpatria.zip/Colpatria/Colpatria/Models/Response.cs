using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace Colpatria.Data 
{
    public partial class Response {
        [Key]
        public int code {get; set;}
        public string description {get; set;}
    }
}
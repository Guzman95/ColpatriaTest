﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Colpatria.Data
{
    public partial class Soat
    {
        public long Id { get; set; }
        public string DatosTomador { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public string PlacaAutomotor { get; set; }
        public long IdCiudad { get; set; }
        public DateTime FechaRegistro { get; set; }

        public virtual Ciudad IdCiudadNavigation { get; set; }
    }
}

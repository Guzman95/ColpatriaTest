﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Colpatria.Data
{
    public partial class Ciudad
    {
        public Ciudad()
        {
            Soats = new HashSet<Soat>();
        }

        public long Id { get; set; }
        public string Descripcion { get; set; }
        public bool? PermiteVenta { get; set; }
        public DateTime FechaRegistro { get; set; }

        public virtual ICollection<Soat> Soats { get; set; }
    }
}

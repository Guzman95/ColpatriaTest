using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Colpatria.Data;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Colpatria.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SoatController : ControllerBase
    {
        private readonly ColpatriaContext _context;

        public SoatController(ColpatriaContext context)
        {
            _context = context;
        }

        // GET: api/Soat
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Soat>>> GetSoat()
        {
            return await _context.Soats.ToListAsync();
        }

        // GET: api/Soat/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Soat>> GetSoat(long id)
        {
            var soat = await _context.Soats.FindAsync(id);

            if (soat == null)
            {
                return NotFound();
            }

            return soat;
        }

        // PUT: api/Soat/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSoat(long id, Soat soat)
        {
            if (id != soat.Id)
            {
                return BadRequest();
            }

            _context.Entry(soat).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SoatExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Soat
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<IEnumerable<Response>>> PostSoat(Soat soat)
        {
            string storedproc = "EXEC SOAT_VentaPoliza @DatosTomador = '" + soat.DatosTomador + "', " + 
            "@FechaInicio = '" + soat.FechaInicio + "', " + 
            "@FechaFin = '" + soat.FechaFin + "', " + 
            "@FechaVencimiento = '" + soat.FechaVencimiento + "', " + 
            "@Placa = '" + soat.PlacaAutomotor + "', " + 
            "@IdCiudad = '" + soat.IdCiudad + "'";

            return await _context.Responses.FromSqlRaw(storedproc).ToListAsync();
        }

        // DELETE: api/Soat/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSoat(long id)
        {
            var soat = await _context.Soats.FindAsync(id);
            if (soat == null)
            {
                return NotFound();
            }

            _context.Soats.Remove(soat);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool SoatExists(long id)
        {
            return _context.Soats.Any(e => e.Id == id);
        }
    }
}
